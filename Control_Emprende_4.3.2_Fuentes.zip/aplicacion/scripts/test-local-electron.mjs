import {_electron as electron} from 'playwright';
import {mkdtemp,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {exerciseLocalWorkspace,assertLocalPersistence} from './local-workspace-scenario.mjs';
const root=process.cwd(),temp=await mkdtemp(path.join(os.tmpdir(),'ce-native-own-'));
const options={executablePath:path.join(root,'desktop/node_modules/electron/dist',process.platform==='win32'?'electron.exe':process.platform==='darwin'?'Electron.app/Contents/MacOS/Electron':'electron'),args:['--disable-gpu',path.join(root,'desktop')],env:{...process.env,CE_TEST_DATA_DIR:temp},timeout:30000};
let app;
try{
 app=await electron.launch(options);const page=await app.firstWindow();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await app.evaluate(({session},temp)=>{globalThis.ceDownloads=[];session.defaultSession.on('will-download',(_event,item)=>{const row={path:temp+'/'+Date.now()+'-'+item.getFilename(),state:'started'};globalThis.ceDownloads.push(row);item.setSavePath(row.path);item.once('done',(_e,state)=>row.state=state);});},temp);
 const downloadFile=async(button)=>{const count=await app.evaluate(()=>globalThis.ceDownloads.length);await button.click();let last;for(let i=0;i<150;i++){last=await app.evaluate((_electron,count)=>globalThis.ceDownloads[count],count);if(last?.state==='completed')return last.path;if(last?.state==='cancelled'||last?.state==='interrupted')throw Error('Download '+last.state);await new Promise(r=>setTimeout(r,100));}throw Error('Download timed out');};
 const expected=await exerciseLocalWorkspace(page,downloadFile);
 assert.equal(await page.evaluate(()=>typeof window.require),'undefined');
 assert(await app.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].webContents.getLastWebPreferences().sandbox));
 assert(await page.evaluate(async()=>{try{await fetch('https://example.com');return false;}catch{return true;}}));
 await app.close();app=null;app=await electron.launch(options);const again=await app.firstWindow();await assertLocalPersistence(again,expected);assert.deepEqual(errors,[]);
 console.log('PASS Electron nativo en Linux: inicio vacío, datos propios, importación, venta/stock, respaldo/restauración, CSV, aislamiento y persistencia al cerrar y abrir.');
 console.log('Pendiente: ejecutar el instalador en Windows real.');
}finally{if(app)await app.close();await rm(temp,{recursive:true,force:true});}
