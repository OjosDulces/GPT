import React,{Suspense,lazy,useEffect,useState} from 'react';
import {createLocalStorage} from '../lib/localStorage.js';
const BusinessApp=lazy(()=>import('../BusinessApp.jsx'));
export default function LocalWorkspace(){
  const [state,setState]=useState('loading'),[error,setError]=useState(''),[attempt,setAttempt]=useState(0);
  useEffect(()=>{
    let active=true;const storage=createLocalStorage();
    setState('loading');setError('');
    storage.getSnapshot().then(()=>{
      if(!active)return;
      window.storage=storage;
      window.businessContext={id:'local-business',name:'Mi negocio',userId:'local',role:'owner',local:true};
      setState('ready');
    }).catch(e=>{if(active){setError(e.message);setState('error');}});
    return()=>{active=false;storage.dispose();if(window.storage===storage){delete window.storage;delete window.businessContext;}};
  },[attempt]);
  if(state==='error')return <main className="ce-panel"><h1>No pudimos abrir tu negocio</h1><p role="alert">{error}</p><p>Tus datos no se han borrado. Cierra otras ventanas y comprueba el espacio del equipo.</p><button className="ce-button" onClick={()=>setAttempt(n=>n+1)}>Reintentar</button></main>;
  if(state!=='ready')return <p role="status">Abriendo tu negocio…</p>;
  return <><div className="ce-demo-bar ce-local-bar"><span><strong>Edición local</strong> · Tu negocio y tus datos, en este equipo</span><span>Respalda desde Ajustes → Datos y respaldo</span></div><Suspense fallback={<p role="status">Abriendo tu espacio…</p>}><BusinessApp/></Suspense></>;
}
