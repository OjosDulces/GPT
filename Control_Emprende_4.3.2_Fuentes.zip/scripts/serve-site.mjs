import {createServer} from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export const site=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../sitio');
const csp="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'none'";
export const server=createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');
  if(['/prueba.html','/app','/descargas/Control_Emprende_Prueba_4.3.zip'].includes(url.pathname)){res.writeHead(302,{Location:'/#descargar'});res.end();return;}
  const file=path.resolve(site,'.'+decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname));
  if(!file.startsWith(site+path.sep))throw Error('Path invalid');
  if(!(await stat(file)).isFile())throw Error('Not a file');
  const mime={'.html':'text/html;charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.bin':'application/octet-stream'}[path.extname(file)];
  res.writeHead(200,{'Content-Type':mime||'application/octet-stream','Content-Security-Policy':csp,'X-Content-Type-Options':'nosniff','Cache-Control':'no-store'});res.end(await readFile(file));
 }catch{res.writeHead(404,{'Content-Type':'text/html;charset=utf-8'});res.end(await readFile(path.join(site,'404.html')));}
});
if(process.argv[1]===fileURLToPath(import.meta.url))server.listen(4174,'127.0.0.1',()=>console.log('Site server listening on port 4174'));
