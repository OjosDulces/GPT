import {createRequire} from 'node:module';
import {readFile,writeFile,mkdir,unlink,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {server,site} from './serve-site.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const {chromium}=createRequire(path.join(root,'aplicacion/package.json'))('playwright');
const output=path.join(root,'pruebas');await mkdir(output,{recursive:true});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const base=`http://127.0.0.1:${server.address().port}`;
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true});
const results=[],errors=[];
const manifest=JSON.parse(await readFile(path.join(site,'descargas/version.json'),'utf8'));
const newPage=async options=>{const p=await browser.newPage(options);p.on('pageerror',e=>errors.push(e.message));p.setDefaultTimeout(15000);return p;};
async function ready(page){await page.goto(base);await page.getByRole('button',{name:'Descargar instalador para Windows',exact:true}).waitFor();}
try{
 for(const width of [1440,1024,768,390,320]){
  const page=await newPage({viewport:{width,height:1000}});await ready(page);
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`overflow at ${width}`);
  assert.equal(await page.locator('a[href*="prueba.html"],a[href$=".zip"],iframe').count(),0);
  assert.equal(await page.evaluate(()=>typeof window.storage),'undefined');
  for(const href of await page.locator('a[href^="#"]').evaluateAll(els=>els.map(el=>el.getAttribute('href'))))assert.equal(await page.locator(href).count(),1);
  const invalid=await page.locator('img').evaluateAll(els=>els.filter(img=>!img.closest('dialog')&&img.complete&&img.naturalWidth===0).map(img=>img.src));assert.deepEqual(invalid,[]);
  if(width<781){await page.getByRole('button',{name:'Abrir menú'}).click();await page.keyboard.press('Escape');assert.equal(await page.getByRole('button',{name:'Abrir menú'}).getAttribute('aria-expanded'),'false');}
  await page.getByRole('tab',{name:/Un espacio a tu manera/}).click();assert.match(await page.locator('#gallery-screenshot').getAttribute('src'),/personalizacion/);
  await page.keyboard.press('ArrowDown');assert.equal(await page.getByRole('tab',{name:/La vitrina/}).getAttribute('aria-selected'),'true');
  await page.getByRole('button',{name:'Ampliar pantalla seleccionada'}).click();await page.getByRole('dialog').waitFor();await page.keyboard.press('Escape');assert.equal(await page.getByRole('dialog').count(),0);
  await page.evaluate(()=>window.scrollTo(0,0));
  if([1440,390].includes(width))await page.screenshot({path:path.join(output,`sitio-${width}.png`),fullPage:true});
  results.push(`PASS interfaz ${width}px: sin desborde, enlaces válidos, galería/teclado y sin aplicación web`);await page.close();
 }
 const page=await newPage({acceptDownloads:true});await ready(page);
 const downloads=[];page.on('download',d=>downloads.push(d.suggestedFilename()));
 // A network failure must not produce a file, and retry must work end to end.
 await page.route('**'+manifest.parts[0].url,route=>route.fulfill({status:503,body:'Unavailable'}));
 await page.locator('#download-installer').click();await page.getByRole('status').filter({hasText:'No se completó'}).waitFor();
 assert.equal(downloads.length,0);assert(await page.getByRole('button',{name:'Reintentar descarga',exact:true}).isEnabled());
 await page.unroute('**'+manifest.parts[0].url);
 // A Pages fallback can return the landing HTML with status 200 for a missing binary.
 const landingHTML=await readFile(path.join(site,'index.html'),'utf8');
 await page.route('**'+manifest.parts[0].url,route=>route.fulfill({status:200,contentType:'text/html',body:landingHTML}));
 await page.locator('#download-installer').click();await page.getByRole('status').filter({hasText:'No se completó'}).waitFor();
 assert.equal(downloads.length,0);assert(await page.getByRole('button',{name:'Reintentar descarga',exact:true}).isEnabled());
 await page.unroute('**'+manifest.parts[0].url);
 results.push('PASS portada HTML devuelta como descarga (HTTP 200): se rechaza y no se guarda un HTML como instalador');
 const completed=page.waitForEvent('download',{timeout:120000});await page.locator('#download-installer').click();const download=await completed;
 const downloaded=await download.path();const bytes=await readFile(downloaded);
 assert.equal(download.suggestedFilename(),manifest.file);assert.equal(bytes.length,manifest.size_bytes);
 assert.equal(createHash('sha256').update(bytes).digest('hex'),manifest.sha256);assert.equal(bytes.subarray(0,2).toString(),'MZ');
 await page.getByRole('status').filter({hasText:'Instalador preparado'}).waitFor();
 results.push(`PASS descarga real tras error 503: ${bytes.length} bytes, .exe y SHA-256 exactos`);
 await page.screenshot({path:path.join(output,'descarga-completa.png'),fullPage:true});
 // Same-length corruption exercises hash verification rather than just length checks.
 const corrupted=Buffer.from(await readFile(path.join(site,manifest.parts[0].url.slice(1))));corrupted[100]^=1;
 await page.route('**'+manifest.parts[0].url,route=>route.fulfill({status:200,contentType:'application/octet-stream',body:corrupted}));
 await page.locator('#download-installer').click();await page.getByRole('status').filter({hasText:'No se completó'}).waitFor();assert.equal(downloads.length,1);
 await page.unroute('**'+manifest.parts[0].url);results.push('PASS archivo alterado: no se entrega un ejecutable corrupto');
 let release,received;const gate=new Promise(r=>release=r),requestStarted=new Promise(r=>received=r);
 await page.route('**'+manifest.parts[0].url,async route=>{received();await gate;await route.abort().catch(()=>{});});
 await page.locator('#download-installer').click();await requestStarted;await page.getByRole('button',{name:'Cancelar descarga'}).click();release();
 await page.getByRole('status').filter({hasText:'Descarga cancelada'}).waitFor();assert.equal(downloads.length,1);await page.unroute('**'+manifest.parts[0].url);
 results.push('PASS cancelar: la descarga se interrumpe y permite volver a empezar');
 for(const route of ['/prueba.html','/app','/descargas/Control_Emprende_Prueba_4.3.zip']){const response=await fetch(base+route,{redirect:'manual'});assert.equal(response.status,302);assert.equal(response.headers.get('location'),'/#descargar');}
 results.push('PASS rutas antiguas redirigen a la descarga (emulación local de _redirects)');
 await page.close();
 const missing=await newPage();await missing.route('**/descargas/version.json',r=>r.fulfill({status:503,body:'Unavailable'}));await missing.goto(base);await missing.getByRole('status').filter({hasText:'No pudimos preparar'}).waitFor();assert(await missing.getByRole('button',{name:'Reintentar descarga'}).isEnabled());await missing.unroute('**/descargas/version.json');await missing.getByRole('button',{name:'Reintentar descarga'}).click();await missing.getByRole('button',{name:'Descargar instalador para Windows',exact:true}).waitFor();await missing.close();
 results.push('PASS metadatos indisponibles: error visible y recuperación');
 const fallback=await newPage();const unexpected=[];fallback.on('download',d=>unexpected.push(d.suggestedFilename()));
 await fallback.route('**/descargas/version.json',route=>route.fulfill({status:200,contentType:'text/html',body:landingHTML}));
 await fallback.goto(base);await fallback.getByRole('status').filter({hasText:'No pudimos preparar'}).waitFor();
 assert.deepEqual(unexpected,[]);assert(await fallback.getByRole('button',{name:'Reintentar descarga',exact:true}).isEnabled());
 await fallback.unroute('**/descargas/version.json');await fallback.getByRole('button',{name:'Reintentar descarga',exact:true}).click();
 await fallback.getByRole('button',{name:'Descargar instalador para Windows',exact:true}).waitFor();await fallback.close();
 results.push('PASS portada HTML en lugar del manifiesto (HTTP 200): error visible, sin descarga falsa y recuperación');

 assert.deepEqual(errors,[]);assert(manifest.parts.every(p=>p.size_bytes<25*1024*1024));
 await writeFile(path.join(output,'sitio-resultados.json'),JSON.stringify({results,errors,installer:{file:manifest.file,size_bytes:manifest.size_bytes,sha256:manifest.sha256},note:'Pruebas locales; no validan un despliegue Cloudflare ni instalación nativa Windows.'},null,2)+'\n');
 console.log(results.join('\n'));
}finally{await browser.close();await new Promise(r=>server.close(r));}
