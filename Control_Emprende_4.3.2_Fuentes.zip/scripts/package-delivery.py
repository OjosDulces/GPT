"""Package existing, verified outputs; building/signing the installer is separate."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parent.parent
version=json.loads((root/'aplicacion/desktop/package.json').read_text())['version']
site=root/'sitio'
manifest=json.loads((site/'descargas/version.json').read_text())
assert manifest['version']==version
installer=root/manifest['file']
assert hashlib.sha256(installer.read_bytes()).hexdigest()==manifest['sha256']
sitezip=root/f'Control_Emprende_{version}_Cloudflare_Pages.zip'
with zipfile.ZipFile(sitezip,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(site.rglob('*')):
  if p.is_file():
   assert p.stat().st_size<25*1024*1024,p
   z.write(p,p.relative_to(site))
excluded_dirs={'node_modules','release','.git','dist','demo-build','landing-build','publicacion-directa'}
excluded_files={'ABRIR_DEMO.html','PAGINA_COMERCIAL.html','EMPIEZA_AQUI.html','CONTENIDO_SHA256.txt','INSTALADOR_SHA256.txt'}
sourcezip=root/f'Control_Emprende_{version}_Fuentes.zip'
with zipfile.ZipFile(sourcezip,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name in ('aplicacion','sitio','scripts','pruebas'):
  for p in sorted((root/name).rglob('*')):
   rel=p.relative_to(root)
   if any(part in excluded_dirs for part in rel.parts) or p.is_symlink() or not p.is_file():continue
   if p.name in excluded_files or p.suffix in {'.bin','.exe'}:continue
   if p.name.startswith('.env') and not p.name.endswith('.example'):continue
   z.write(p,rel)
 for name in ('LEEME_ENTREGA.md','SHA256SUMS.txt',f'build-windows-{version}.log'):
  z.write(root/name,name)
 z.writestr('NOTA_DOCUMENTACION.md','La documentación vigente es LEEME_ENTREGA.md y pruebas/RESULTADOS_'+version+'.md. Los documentos de aplicacion/docs y las guías originales son antecedentes de versiones anteriores. Las partes del instalador se regeneran y no están incluidas en las fuentes. Los registros de prueba conservan el resultado y la versión de cada ejecución; los fallos de diagnóstico documentan la reproducción del error antes de corregirlo.\n')
for archive in (sitezip,sourcezip):
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 print(archive.name,archive.stat().st_size,'bytes',hashlib.sha256(archive.read_bytes()).hexdigest())
