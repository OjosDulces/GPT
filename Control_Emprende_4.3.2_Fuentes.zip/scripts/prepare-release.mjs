import {readFile,writeFile,readdir,unlink,rename,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const {version}=JSON.parse(await readFile(path.join(root,'aplicacion/desktop/package.json'),'utf8'));
const file=`Control-Emprende-${version}-Windows-x64-Instalador.exe`;
const bytes=await readFile(path.join(root,'aplicacion/desktop/release',file));
if(bytes.length<10*1024*1024||bytes.subarray(0,2).toString()!=='MZ')throw Error('Missing or invalid Windows installer');
const hash=data=>createHash('sha256').update(data).digest('hex');
const sha256=hash(bytes),output=path.join(root,'sitio/descargas');await mkdir(output,{recursive:true});
const parts=[];
for(let offset=0,index=1;offset<bytes.length;offset+=16*1024*1024,index++){
 const part=bytes.subarray(offset,offset+16*1024*1024);
 const name=`control-emprende-${version}-${sha256.slice(0,12)}-${String(index).padStart(2,'0')}.bin`;
 await writeFile(path.join(output,name),part);
 parts.push({url:'/descargas/'+name,size_bytes:part.length,sha256:hash(part)});
}
const manifest={version,file,platform:'windows-x64',size_bytes:bytes.length,sha256,parts};
await writeFile(path.join(output,'version.json.tmp'),JSON.stringify(manifest,null,2)+'\n');
await rename(path.join(output,'version.json.tmp'),path.join(output,'version.json'));
const current=new Set(parts.map(p=>path.basename(p.url)));
for(const name of await readdir(output))if(/^control-emprende-[\w.-]+\.bin$/.test(name)&&!current.has(name))await unlink(path.join(output,name));
await writeFile(path.join(root,file),bytes);
await writeFile(path.join(root,'SHA256SUMS.txt'),sha256+'  '+file+'\n');
console.log(JSON.stringify(manifest,null,2));
