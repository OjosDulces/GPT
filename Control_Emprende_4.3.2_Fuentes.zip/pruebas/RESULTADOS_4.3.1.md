# Validación de Control Emprende 4.3.1

- 69 pruebas automatizadas de dominio, datos, almacenamiento, políticas de escritorio y servicios: aprobadas, sin fallos.
- Aplicación compilada: primer inicio vacío; actividad mixta; importación de productos y clientes propios; ventas y descuento de stock; catálogo local; exportación CSV; respaldo y restauración; persistencia al reiniciar. Sin solicitudes externas ni errores JavaScript durante estos escenarios.
- Almacenamiento: aislamiento respecto de las antiguas demos, detección de escrituras concurrentes, rechazo de datos inválidos y conservación de una base dañada sin reinicio destructivo.
- Electron nativo en Linux: escenario de datos propios, importación, venta, respaldo/restauración, CSV y persistencia al cerrar y volver a abrir aprobado.
- Inicio: 10 combinaciones de tema claro/oscuro y ancho entre 320 y 1440 px. Tres secciones con separación visible, tarjetas diferenciadas y sin desbordamiento horizontal.
- Sitio: cinco anchos entre 320 y 1440 px, navegación y galería con teclado, sin aplicación web. Descarga completa del instalador 4.3.1 (105769068 bytes), con verificación SHA-256. Casos de error 503, reintento, cancelación, archivo alterado y metadatos indisponibles aprobados. Redirecciones antiguas comprobadas mediante emulación local.
- Instalador Windows: compilación terminada correctamente y contenido empaquetado inspeccionado. La página descarga exactamente el binario generado.

## Límites de esta validación

No se ejecutó Windows: instalación, actualización y desinstalación necesitan una prueba en ese sistema. El ejecutable no tiene firma digital del editor. La URL pública de Cloudflare no se modificó; la validación del sitio se realizó localmente. Las pruebas de servicios heredados no equivalen a validar un despliegue de servicios en la nube.

Los registros y capturas adjuntos detallan cada escenario. Los datos de las pruebas se crean en perfiles temporales y no se distribuyen en el instalador.
